(function(){
	var app = angular.module("app");
	app.value("appvc","My First Application");
})
();
