

(function(){
	var app = angular.module("app");
app.service("appsvc",function(appvc){

this.name=appvc;
this.author="king",
this.Rights="CopyRights Reserved"
});

})();
