(function(){
	var app = angular.module("app");
	app.service("contactdatasvc",function($http){

		var self =this;
		self.getcontacts= function(){
			var promise1= $http.get("http://localhost:3000/contacts/");
			var promise2= promise1.then(function(response){
				
				return response.data;
			});

			return promise2;
		}

		
	});

})();
