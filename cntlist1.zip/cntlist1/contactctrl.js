(function(){
  var app = angular.module("app");
  app.controller("contactctrl",contactctrl);


  function contactctrl(contactdatasvc){
    var self=this;
    contactdatasvc.getcontacts()
    .then(function(data){
      self.contacts=data;
    })




    this.sel= function($index){
      this.selected=this.contacts[$index];  
    }
  }
})();

