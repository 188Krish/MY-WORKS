export { DatabindingComponent } from './databinding.component';
export { PropertyBindingComponent } from './property-binding.component';
