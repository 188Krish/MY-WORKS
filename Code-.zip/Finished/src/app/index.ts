export {environment} from './environment';
export {FirstAppAppComponent} from './first-app.component';
