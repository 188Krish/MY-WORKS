(function(){
	angular.module("app")
	.controller("quizctrl",quizctrl);


	quizctrl.$inject =['quizmetrics','dataservice'];

	function quizctrl(quizmetrics,dataservice){

		this.quizmetrics=quizmetrics;
		this.dataservice=dataservice;
		this.questionanswered=questionanswered;
		this.setactivequestion=setactivequestion;
		this.activequestion=0;
		var numquesanswrd=0;
		function setactivequestion(){
			var breakout=false;
			var quizlength=dataservice.quizQuestions.length-1;

			while(!breakout){
				this.activequestion= this.activequestion<quizQuestions?++this.activequestion:0;
				if(dataservice.quizQuestions[this.activequestion].selected ===null){
					breakout=true;
				}

			}
		}
	}


	function questionanswered(){
		var quizlength = dataservice.quizQuestions.length;

		if (dataservice.quizQuestions[this.activequestion].selected !== null) {
			numquesanswrd++;
			if(numquesanswrd >= quizlength){

			}
		}
		this.setactivequestion();
	}
})();