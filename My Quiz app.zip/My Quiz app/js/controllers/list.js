(function(){
angular.module("app")
       .controller("control",listcontrol);

listcontrol.$inject =['quizmetrics','dataservice'];

function listcontrol(quizmetrics,dataservice){


    this.quizmetrics=quizmetrics;
    this.data=dataservice.data;
	this.activeturtle={};
	this.ChangeActTurtle =ChangeActTurtle;
    this.search="";
    this.activatequiz=activatequiz;

	function ChangeActTurtle(index){
		this.activeturtle=index;
		
	}
	
	function activatequiz(){
		quizmetrics.changestate(true);
	}



}

})();