(function(){
	angular.module("app")
	.factory("quizmetrics", quizmetrics);

	function quizmetrics(){
		var quizobj={
			quiz:false,
			changestate: changestate
		};

		return quizobj;

		function changestate(state){
			quizobj.quiz= state;
		}
	}

})(); 