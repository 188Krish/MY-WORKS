var React = require('react');
var ReactDOM = require('react-dom');
var {Route,Router,IndexROute,hashHistory}= require('react-router');

ReactDOM.render(
  <h1>Boilerplate app!</h1>,
  document.getElementById('app')
);
