module.exports={
entry:'./public/app.jsx',
output:{
	path:__dirname,
	filename:'./public/bundle.js'
},
resolve:{
	extension:['','.js','.jsx']
},
module:{
	loaders:[
	{
		loader:'babel-loader',
		query:{
			presets:['react','es2015']

		},
		test:/\.jsx?$/,
		exculde:/(node_module|bower_components)/
	}
	]
}

};