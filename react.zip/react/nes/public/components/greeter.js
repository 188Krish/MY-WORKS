function greeter () {
    document.write('from greeter');
}

greeter();

modules.exports =greeter;