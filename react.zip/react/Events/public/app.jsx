	var Greeter = React.createClass({
	getDefaultProps: function(){
	return {
	name:'React',
    Pro:'Component'    
	};
	},
	
    onButtonclick: function(e){
        e.preventDefault(); //prevent relodading from entire whole page
        var name =this.refs.name.value;
        alert(name);
    },
        
	render: function(){
	var firstname =this.props.name;
	var Prop= this.props.Pro;
	return (
	<div>
	<h1>Hello {firstname}!</h1>
	<p>This is  from {Prop}!</p>
    <form onSubmit={this.onButtonclick}>
        <input text="text" ref="name">
        </input>
        <button>Submit</button>
    </form>
	</div>
	);
	}
	});

    

	ReactDOM.render(
	<Greeter name="Krishna" Pro=" properties" /> ,
	document.getElementById('app')
	);
