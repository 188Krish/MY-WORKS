var Greeter = React.createClass({
getDefaultProps: function(){
return {
name:'React',
Pro:'Component'    
};
},
getIntialState: function(){
return{
name:this.props.name  
}; 
}, 

onButtonclick: function(e){
e.preventDefault(); //prevent relodading from entire whole page
var name =this.refs.name.value;

this.setState({
name:name
});
},


render: function(){
var name =this.state.name;
var Prop= this.props.Pro;

return (
<div>

<h1>Hello {name}!</h1>

<p>This is  from {Prop}!</p>

<form onSubmit={this.onButtonclick}>


<input text="text" ref="name"> </input>

<button>Submit</button>
</form>
</div>
);
}
});



ReactDOM.render(
<Greeter name="Krishna" Pro=" properties" /> ,
document.getElementById('app')
);
